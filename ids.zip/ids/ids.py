import csv
from tkinter.filedialog import asksaveasfilename
import pyshark
import ipaddress
import time
import time
import re
from collections import defaultdict


LOG_FILE = "Packets.csv"
THRESHOLD = 3
TIME_WINDOW = 60
LOG_FILE1 = "flag.log"
FAIL_REGEX = re.compile(r"Failed password for .* from (\d+\.\d+\.\d+\.\d+)")
ipsrc_counter = defaultdict(int)




def create_log():

      with open(LOG_FILE, "w",newline="") as f:
            
            writer = csv.writer(f)
            
            writer.writerow([

            "timestamp",
            "source_ip",
            "destination_ip",
            "source_port",
            "destination_port",
            "transport_layer",
            "hightest_layer",
            "packet_size",
            "packet_rate",
            "activity",
            "flag",
            "reason",
            "rule_triggered"
            
            ])
            


class Packet:
    def __init__(
            self,
            time_stamp:str='',
            ipsrc:str='',
            ipdst:str='',
            srcport:str='',
            dstport:str='',
            transport_layer:str='',
            highest_layer:str='',
            packet_size:str='',
            packet_rate:str='',
            activity:str='',
            flag:str='',
            reason:str='',
            rule_triggered:str=''
    ):
        self.time_stamp = time_stamp
        self.ipsrc = ipsrc
        self.ipdst = ipdst
        self.srcport = srcport
        self.dstport = dstport
        self.transport_layer = transport_layer
        self.highest_layer = highest_layer
        self.packet_size = packet_size
        self.packet_rate = packet_rate
        self.activity = activity
        self.flags = flag
        self.reason = reason
        self.rule_triggered = rule_triggered
        
def alert(ipsrc): 

      with open(LOG_FILE1, "a", newline="", encoding="utf-8") as f:
            f.write("[!] ALERT: Multiple failed log entries with malicious activity from "+" "+ipsrc+"\n")

def create_flag_log():
      with open(LOG_FILE1, "w") as f:
            pass
def simulate_log_read():
    with open(LOG_FILE1, "r", newline="", encoding="utf-8") as f:
      for line in f:
            yield line
            time.sleep(0.5)
def check_line(ipsrc):
      
      

      ipsrc_counter[ipsrc] += 1
      
      
      if ipsrc_counter[ipsrc] == THRESHOLD:
                  
                  alert(ipsrc)

                  print("[!] ALERT: Multiple failed log entries with malicious activity from "+" "+ipsrc+"")
                  
                  ipsrc_counter[ipsrc] = 0



def is_private_ip(ip_address:str)->bool:
   '''
    Determines if the ip address is private
   '''
   
   ip = ipaddress.ip_address(ip_address)
   return ip.is_private


def log(packet):
      with open(LOG_FILE, "a", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow([
            
            packet.time_stamp,
            packet.ipsrc,
            packet.ipdst,
            packet.srcport,
            packet.dstport,
            packet.transport_layer,
            packet.highest_layer,
            packet.packet_size,
            packet.packet_rate,
            packet.activity,
            packet.flags,
            packet.reason,
            packet.rule_triggered
           
      ])
            
 


def filter_packet(packet):
    '''

    Filters packet from capture

    '''
    if packet.transport_layer not in ['TCP', 'UDP']:

        return None
    if hasattr(packet,'ipv6'):
            
            return None
    if not hasattr(packet, 'ip'):

            return None
   
    DataPkt = Packet()
    DataPkt.ipsrc = packet.ip.src
    DataPkt.ipdst = packet.ip.dst
    ipsrc_counter[DataPkt.ipsrc] += 1
    DataPkt.time_stamp = packet.sniff_time.isoformat()
    DataPkt.highest_layer= packet.highest_layer
    DataPkt.packet_size = int(packet.length)
    DataPkt.packet_rate = ipsrc_counter[DataPkt.ipsrc]
    
    
    DataPkt.transport_layer = packet.transport_layer
    if packet.transport_layer == 'UDP' and hasattr(packet,'udp'):
                  DataPkt.dstport = packet.udp.dstport
                  DataPkt.srcport = packet.udp.srcport
    elif packet.transport_layer == 'TCP' and hasattr(packet, 'tcp'):
                  DataPkt.dstport = packet.tcp.dstport
                  DataPkt.srcport = packet.tcp.srcport
      

                  
    return DataPkt

def intrusion(DataPkt):
      
      engine = DetectionEngine()
      return engine.detect_threats(DataPkt)
      
      

class DetectionEngine:
      
      def __init__(self):
           self.signature_rules = self.load_signature_rules()
           self.training_data = []
           
      def load_signature_rules(self):
                 return{
                       'malicious HTTPS traffic': {
                             'condition': lambda pkt: pkt.dstport == "443",
                             'message':'Suspicious activity on port 443'


                       },
                       'syn flood': {
                             'condition': lambda packet: (
                                   packet.flags == 2 and
                                   packet.transport_layer == 'TCP'
                             )},
                        'port scan': {
                               'condition': lambda packet: (
                                    packet.packet_size < 100 and
                                    packet.packet_rate > 50
            )
      }
                       }
      def detect_threats(self,packet):
            
            rule_name = [] 

            for rule_name, rule in self.signature_rules.items():
                  if rule['condition'](packet):
                        packet.activity = 'Malicious' 
                        packet.reason = 'Suspicious traffic'
                        packet.rule_triggered = rule_name
                        return packet
                  else:
                        packet.activity = 'Normal'
                        packet.reason = 'Normal traffic'
                        packet.rule_triggered = 'None'
                        return packet
                  



def run_pcap():
      filename = input("Enter file name: ")
      capture = pyshark.FileCapture(filename)

      print(f"[*] Simulated IDS monitoring {LOG_FILE1}...\n")

      for packet in capture:
            
            filtered = filter_packet(packet)

            if filtered:
                  detected = intrusion(filtered)


                  if detected.activity == "Malicious":
                        
                        print(detected.__dict__)

                        check_line(detected.ipsrc)
                        
                        
                        log(detected)
                        
                  else:
                        
                        print(detected.__dict__)

                        log(detected)

                  

                  



def run_live():
      
      interface = input("Enter interface name: ")
      capture = pyshark.LiveCapture(interface=interface)

      print(f"[*] Simulated IDS monitoring {LOG_FILE1}...\n")

      for packet in capture.sniff_continuously():

            filtered = filter_packet(packet)

            if filtered:
                  detected = intrusion(filtered)
                  
                  if detected.activity == "Malicious":
                        
                        print(detected.__dict__)

                        check_line(detected.ipsrc)
                        
                        
                        log(detected)
                        
                  else:
                        
                        print(detected.__dict__)

                        log(detected)

                  





def main():
      
      
      print("Select Mode:")
      print("1 = PCAP File")
      print("2 = Live Capture")

      choice = input("Choice: ")

      if choice == "1":
            run_pcap()
            
            
      elif choice == "2":
             run_live() 
         

            
      
      else:
            print("Invalid choice")
            return
      
if __name__ == "__main__":

      create_log()

      create_flag_log()

      main()
     